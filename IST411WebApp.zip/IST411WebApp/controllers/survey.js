var exports = module.exports = {};

exports.showSurvey = function(req, res) {
    res.render('surveyPage');
}