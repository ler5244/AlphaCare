module.exports = {
    mongoURI: 'mongodb://admin:password1@ds041939.mlab.com:41939/thedevconnector'
}